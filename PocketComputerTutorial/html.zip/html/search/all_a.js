var searchData=
[
  ['powerunits_25',['PowerUnits',['../class_computer_hardware_guide_1_1_a_p_i_1_1_a_p_i_context.html#a5e2ccbc0d13db3c451ee0ae7c1db6633',1,'ComputerHardwareGuide::API::APIContext']]]
];
