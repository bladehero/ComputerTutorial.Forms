var searchData=
[
  ['api_35',['API',['../namespace_computer_hardware_guide_1_1_a_p_i.html',1,'ComputerHardwareGuide']]],
  ['computerhardwareguide_36',['ComputerHardwareGuide',['../namespace_computer_hardware_guide.html',1,'']]]
];
