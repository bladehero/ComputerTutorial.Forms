var searchData=
[
  ['hdds_55',['HDDs',['../class_computer_hardware_guide_1_1_a_p_i_1_1_a_p_i_context.html#ae522569763ddd6bc641883461f3032c2',1,'ComputerHardwareGuide::API::APIContext']]]
];
