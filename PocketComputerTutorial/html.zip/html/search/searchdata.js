var indexSectionsWithContent =
{
  0: "_abcdeghmoprs",
  1: "abe",
  2: "c",
  3: "a",
  4: "ahs",
  5: "_",
  6: "acdeghmoprs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Properties"
};

