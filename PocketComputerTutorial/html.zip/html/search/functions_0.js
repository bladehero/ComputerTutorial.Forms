var searchData=
[
  ['apicontext_39',['APIContext',['../class_computer_hardware_guide_1_1_a_p_i_1_1_a_p_i_context.html#a227e8ffcc4a51f408836bf8d5b298380',1,'ComputerHardwareGuide::API::APIContext']]]
];
