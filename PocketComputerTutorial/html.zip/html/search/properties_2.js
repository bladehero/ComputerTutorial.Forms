var searchData=
[
  ['data_50',['Data',['../class_computer_hardware_guide_1_1_a_p_i_1_1_base_api_response.html#aa620af9d2d67bffa5b009a88c4fcf15e',1,'ComputerHardwareGuide::API::BaseApiResponse']]]
];
