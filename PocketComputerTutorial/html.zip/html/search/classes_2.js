var searchData=
[
  ['error_34',['Error',['../class_computer_hardware_guide_1_1_a_p_i_1_1_error.html',1,'ComputerHardwareGuide::API']]]
];
