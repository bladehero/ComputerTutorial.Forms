var searchData=
[
  ['setapiurl_41',['SetApiUrl',['../class_computer_hardware_guide_1_1_a_p_i_1_1_a_p_i_context.html#a05d2748d1f4ae4d854307848a138f1d8',1,'ComputerHardwareGuide::API::APIContext']]],
  ['sethandler_42',['SetHandler',['../class_computer_hardware_guide_1_1_a_p_i_1_1_a_p_i_context.html#a5b7c2ec4fa8c3d25f209e23dce0d7f40',1,'ComputerHardwareGuide::API::APIContext']]]
];
