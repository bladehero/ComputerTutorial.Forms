var searchData=
[
  ['assemblies_46',['Assemblies',['../class_computer_hardware_guide_1_1_a_p_i_1_1_a_p_i_context.html#ae3ff177a0959b1bae8820fed0fc8fa3d',1,'ComputerHardwareGuide::API::APIContext']]]
];
