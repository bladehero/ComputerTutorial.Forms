var files_dup =
[
    [ "ComputerHardwareGuide.API", "dir_ab5b5a7b218dbcb45c9925975f427afe.html", "dir_ab5b5a7b218dbcb45c9925975f427afe" ]
];