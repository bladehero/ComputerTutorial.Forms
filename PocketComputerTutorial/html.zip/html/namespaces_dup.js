var namespaces_dup =
[
    [ "ComputerHardwareGuide", "namespace_computer_hardware_guide.html", "namespace_computer_hardware_guide" ]
];