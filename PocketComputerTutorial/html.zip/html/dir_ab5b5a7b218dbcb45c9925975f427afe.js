var dir_ab5b5a7b218dbcb45c9925975f427afe =
[
    [ "APIContext.cs", "_a_p_i_context_8cs.html", [
      [ "APIContext", "class_computer_hardware_guide_1_1_a_p_i_1_1_a_p_i_context.html", "class_computer_hardware_guide_1_1_a_p_i_1_1_a_p_i_context" ]
    ] ],
    [ "ApplicationHttpClient.cs", "_application_http_client_8cs.html", [
      [ "BaseApiResponse", "class_computer_hardware_guide_1_1_a_p_i_1_1_base_api_response.html", "class_computer_hardware_guide_1_1_a_p_i_1_1_base_api_response" ],
      [ "BaseApiResponse", "class_computer_hardware_guide_1_1_a_p_i_1_1_base_api_response.html", "class_computer_hardware_guide_1_1_a_p_i_1_1_base_api_response" ],
      [ "Error", "class_computer_hardware_guide_1_1_a_p_i_1_1_error.html", "class_computer_hardware_guide_1_1_a_p_i_1_1_error" ],
      [ "ApplicationHttpClient", "class_computer_hardware_guide_1_1_a_p_i_1_1_application_http_client.html", "class_computer_hardware_guide_1_1_a_p_i_1_1_application_http_client" ]
    ] ]
];