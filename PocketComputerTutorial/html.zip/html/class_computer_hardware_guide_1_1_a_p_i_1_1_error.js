var class_computer_hardware_guide_1_1_a_p_i_1_1_error =
[
    [ "ErrorCode", "class_computer_hardware_guide_1_1_a_p_i_1_1_error.html#a7ffefb24e1aaedb38b13bdf47cbe05a3", null ],
    [ "ErrorText", "class_computer_hardware_guide_1_1_a_p_i_1_1_error.html#a4fc07bed1a4a7168f4e33687721550b9", null ]
];